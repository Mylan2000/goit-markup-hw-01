# Homework #1 — HTML Markup

This is a project for GoIT Fullstack Developer course.

## Task
- Create semantic HTML markup for a simple layout
- No CSS styling included
- All images stored in the `images/` folder

## Live Page
[See on GitHub Pages](https://your-username.github.io/goit-markup-hw-01/)
